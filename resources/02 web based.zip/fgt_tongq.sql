-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2020 at 05:29 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fgt_tongq`
--
CREATE DATABASE IF NOT EXISTS `fgt_tongq` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fgt_tongq`;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hp` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Laki-laki','Perempuan') COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('fgt','own','emp') COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `picture` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cafes`
--

CREATE TABLE `cafes` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idOwner` int(10) UNSIGNED NOT NULL,
  `noHp` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noWA` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subDistrict` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `province` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` int(11) DEFAULT NULL,
  `timeOpen` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timeClose` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `picture` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_open` tinyint(4) NOT NULL DEFAULT 0,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `lang` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `long` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cafe_access`
--

CREATE TABLE `cafe_access` (
  `idAdm` int(10) UNSIGNED NOT NULL,
  `idCafe` int(10) UNSIGNED NOT NULL,
  `is_confirm` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hp` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Laki-laki','Perempuan') COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 0,
  `picture` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `idCafe` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `categori` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `is_available` tinyint(4) NOT NULL DEFAULT 1,
  `picture` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_categories`
--

CREATE TABLE `menu_categories` (
  `categori` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createBy` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(34, '2020_02_10_152151_create_admins_table', 1),
(35, '2020_02_10_152230_create_customers_table', 1),
(36, '2020_02_10_152258_create_cafes_table', 1),
(37, '2020_02_10_152337_create_menu_categories_table', 1),
(38, '2020_02_10_152810_create_tables_table', 1),
(39, '2020_02_10_152832_create_menus_table', 1),
(40, '2020_02_10_152903_create_transactions_table', 1),
(41, '2020_02_10_152939_create_transaction_details_table', 1),
(42, '2020_02_10_153052_create_reports_table', 1),
(43, '2020_02_10_153205_create_trigger', 1),
(44, '2020_02_10_160817_create_cafe_access_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `idCafe` int(10) UNSIGNED NOT NULL,
  `date` date NOT NULL,
  `trans` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tables`
--

CREATE TABLE `tables` (
  `id` int(10) UNSIGNED NOT NULL,
  `idCafe` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `capacity` tinyint(4) DEFAULT NULL,
  `is_empty` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `idCafe` int(10) UNSIGNED NOT NULL,
  `idEmp` int(10) UNSIGNED NOT NULL,
  `idCus` int(10) UNSIGNED DEFAULT NULL,
  `idTbl` int(10) UNSIGNED DEFAULT NULL,
  `peoples` tinyint(4) DEFAULT NULL,
  `booking_at` timestamp NULL DEFAULT NULL,
  `transaction_at` timestamp NULL DEFAULT NULL,
  `status` enum('booking','success','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL,
  `comment` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no comment'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Triggers `transactions`
--
DELIMITER $$
CREATE TRIGGER `trgReport_afIns_tbTransactions` AFTER INSERT ON `transactions` FOR EACH ROW BEGIN 
          IF NEW.status = 'success' THEN 
            IF (SELECT COUNT(*) FROM reports WHERE idCafe=NEW.idCafe AND date=DATE(NEW.transaction_at)) > 0 THEN 
              UPDATE reports SET total=total+NEW.total, trans=trans+1 WHERE idCafe=NEW.idCafe AND date=DATE(NEW.transaction_at); 
            ELSE 
              INSERT INTO reports(idCafe,date,trans,total) VALUES(NEW.idCafe, DATE(NEW.transaction_at), 1, NEW.total); 
            END IF;
          END IF;
        END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `trgReport_afUp_tbTransactions` AFTER UPDATE ON `transactions` FOR EACH ROW BEGIN 
          IF NEW.status = 'success' THEN 
            IF (SELECT COUNT(*) FROM reports WHERE idCafe=NEW.idCafe AND date=DATE(NEW.transaction_at)) > 0 THEN 
              UPDATE reports SET total=total+NEW.total, trans=trans+1 WHERE idCafe=NEW.idCafe AND date=DATE(NEW.transaction_at); 
            ELSE 
              INSERT INTO reports(idCafe,date,trans,total) VALUES(NEW.idCafe, DATE(NEW.transaction_at), 1, NEW.total); 
            END IF;
          END IF;
        END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--

CREATE TABLE `transaction_details` (
  `idTrans` int(10) UNSIGNED NOT NULL,
  `idMenu` int(10) UNSIGNED NOT NULL,
  `price` int(11) NOT NULL,
  `lots` tinyint(4) NOT NULL,
  `subTotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cafes`
--
ALTER TABLE `cafes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cafes_idowner_foreign` (`idOwner`);

--
-- Indexes for table `cafe_access`
--
ALTER TABLE `cafe_access`
  ADD PRIMARY KEY (`idAdm`,`idCafe`),
  ADD KEY `cafe_access_idcafe_foreign` (`idCafe`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `menus_idcafe_foreign` (`idCafe`),
  ADD KEY `menus_categori_foreign` (`categori`);

--
-- Indexes for table `menu_categories`
--
ALTER TABLE `menu_categories`
  ADD PRIMARY KEY (`categori`),
  ADD KEY `menu_categories_createby_foreign` (`createBy`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`idCafe`,`date`);

--
-- Indexes for table `tables`
--
ALTER TABLE `tables`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tables_idcafe_foreign` (`idCafe`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactions_idcafe_foreign` (`idCafe`),
  ADD KEY `transactions_idemp_foreign` (`idEmp`),
  ADD KEY `transactions_idcus_foreign` (`idCus`),
  ADD KEY `transactions_idtbl_foreign` (`idTbl`);

--
-- Indexes for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`idTrans`,`idMenu`),
  ADD KEY `transaction_details_idmenu_foreign` (`idMenu`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cafes`
--
ALTER TABLE `cafes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `tables`
--
ALTER TABLE `tables`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cafes`
--
ALTER TABLE `cafes`
  ADD CONSTRAINT `cafes_idowner_foreign` FOREIGN KEY (`idOwner`) REFERENCES `admins` (`id`);

--
-- Constraints for table `cafe_access`
--
ALTER TABLE `cafe_access`
  ADD CONSTRAINT `cafe_access_idadm_foreign` FOREIGN KEY (`idAdm`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `cafe_access_idcafe_foreign` FOREIGN KEY (`idCafe`) REFERENCES `cafes` (`id`);

--
-- Constraints for table `menus`
--
ALTER TABLE `menus`
  ADD CONSTRAINT `menus_categori_foreign` FOREIGN KEY (`categori`) REFERENCES `menu_categories` (`categori`),
  ADD CONSTRAINT `menus_idcafe_foreign` FOREIGN KEY (`idCafe`) REFERENCES `cafes` (`id`);

--
-- Constraints for table `menu_categories`
--
ALTER TABLE `menu_categories`
  ADD CONSTRAINT `menu_categories_createby_foreign` FOREIGN KEY (`createBy`) REFERENCES `admins` (`id`);

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_idcafe_foreign` FOREIGN KEY (`idCafe`) REFERENCES `cafes` (`id`);

--
-- Constraints for table `tables`
--
ALTER TABLE `tables`
  ADD CONSTRAINT `tables_idcafe_foreign` FOREIGN KEY (`idCafe`) REFERENCES `cafes` (`id`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_idcafe_foreign` FOREIGN KEY (`idCafe`) REFERENCES `cafes` (`id`),
  ADD CONSTRAINT `transactions_idcus_foreign` FOREIGN KEY (`idCus`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `transactions_idemp_foreign` FOREIGN KEY (`idEmp`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `transactions_idtbl_foreign` FOREIGN KEY (`idTbl`) REFERENCES `tables` (`id`);

--
-- Constraints for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD CONSTRAINT `transaction_details_idmenu_foreign` FOREIGN KEY (`idMenu`) REFERENCES `menus` (`id`),
  ADD CONSTRAINT `transaction_details_idtrans_foreign` FOREIGN KEY (`idTrans`) REFERENCES `transactions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
